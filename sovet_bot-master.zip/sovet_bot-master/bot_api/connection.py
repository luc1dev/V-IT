import vk_api

token = '4724ad5ffc5bf218e4964d262dc1fee697edd93ef5775d1dfc5abdc719c592cba8b0f818aee48f143537d'
confirmation_token = 'fbc87f82'
vk_session = vk_api.VkApi(token=token)
confirmation_token_ingut = '86938920'
token_ingut = '6c88f38b38618980b2ec2396bb59edf68b3e272816dca0cc2346995fe3da19b6f75015e359f90f945ef6d'
vk_session_ingut = vk_api.VkApi(token=token_ingut)

library_api = 'https://1nform-microservices-library-dev.cluster.1nform.ru/api/v1'


