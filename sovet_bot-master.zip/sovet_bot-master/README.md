# flask-test-blog

Бот для сс спбгут


ипользуемые технологии: 
-SQLAlchemy
-Flask
-vkapi

база данных - sqlite
